#!/bin/bash
# Author - brarm
set -e

sudo systemctl is-active --quiet docker || sudo service docker start && echo Docker is running

ecr=
service=
cluster=
opts=

read -p "[D]ev or {L}ive: " deploy;

if
    [[ "$deploy" == [Dd] ]] ||
    [[ "$deploy" =~ "^[Dd]" ]] ||
    [[ "{$deploy^^}" == "DEV" ]] ||
    [[ "$deploy" == "" ]];
then
    echo "Deploying dev"
    ecr='cda-penguin-app'
    service='dev-wb-fargate-service'
    cluster='dev-wb-fargate-cluster'
elif
    [[ "$deploy" == [Ll] ]] ||
    [[ "$deploy" =~ "^[Ll]" ]] ||
    [[ "{$deploy^^}" == "LIVE" ]];
then
    echo "Deploying live"
    ecr='cda-penguin-app'
    service='wb-fargate-service'
    cluster='wb-fargate-cluster'
    opts="--no-cache --force-rm"
fi

echo "---------------------------"
echo "ECR    : $ecr"
echo "SERVICE: $service"
echo "CLUSTER: $cluster"
echo "OPTS   : $opts"
echo "---------------------------"

docker_opts=''

if [[ -z $opts ]];
then
        docker_opts=(-t "${ecr}" .)
else
        docker_opts=(-t "${ecr}" "${opts}" .)
fi

sudo docker build "${docker_opts[@]}"

$(aws ecr get-login --no-include-email --region ap-southeast-1)
ecr_repo_url=$(aws ecr describe-repositories --region ap-southeast-1 --repository-names $ecr --query "repositories[0].repositoryUri" --output text)
sudo docker tag "$ecr:latest" "$ecr_repo_url:latest"
sudo docker push "$ecr_repo_url:latest"

#sleep 2
#aws ecs update-service --force-new-deployment --service "$service" --cluster "$cluster"
